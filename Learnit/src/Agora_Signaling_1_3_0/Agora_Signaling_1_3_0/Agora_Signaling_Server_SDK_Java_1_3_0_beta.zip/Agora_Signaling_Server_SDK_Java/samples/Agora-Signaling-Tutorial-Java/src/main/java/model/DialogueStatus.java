package model;

public enum DialogueStatus {
	UNLOGIN, LOGINED, SINGLE_POINT, CHANNEL,SIGNALINSTANCE,CHOOSESIGNAL
}
