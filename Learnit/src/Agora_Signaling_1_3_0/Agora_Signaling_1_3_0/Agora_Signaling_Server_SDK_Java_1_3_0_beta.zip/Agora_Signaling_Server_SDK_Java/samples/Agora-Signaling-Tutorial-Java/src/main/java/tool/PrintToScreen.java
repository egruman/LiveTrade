package tool;

public class PrintToScreen {
	public static void printToScreen(String msg){
		System.out.print(msg);	
	}
	public static void printToScreenLine(String msg){
		System.out.println(msg);	
	}

}
