//
//  KeyCenter.swift
//  Agora-Signaling-Tutorial
//
//  Created by ZhangJi on 04/12/2017.
//  Copyright © 2017 ZhangJi. All rights reserved.
//

struct KeyCenter {
    static let AppId: String = <#Your App Id#>
}
